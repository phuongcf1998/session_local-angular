export const ERROR_STATUS = 404;
export const FALSE_VALUE_LOCAL_STORAGE = 'false';
export const TRUE_VALUE_LOCAL_STORAGE = 'true';
export const TRUE_VALUE_BOOLEAN = true;
export const FALSE_VALUE_BOOLEAN = false;
export const USER = {
  username: 'admin',
  password: 'P@ssw0rd',
  email: 'a@b.c',
  firstName: 'John',
  lastName: 'Doe',
};
export const MESSAGE_INVALID_PAYLOAD = 'Invalid request payload input';
export const SIGN_UP_SUCCESS_MESSAGE = 'Sign Up Success';
export const UPDATE_PROFILE_SUCCESS_MESSAGE = 'Update Success';
